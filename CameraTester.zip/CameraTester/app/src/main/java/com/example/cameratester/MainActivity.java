package com.example.cameratester;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SizeF;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.CamcorderProfile;
import android.os.Build;
import android.os.Bundle;
import android.util.Range;
import android.util.Size;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView out;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        out = new TextView(this);
        out.setPadding(32, 32, 32, 32);
        out.setTextSize(13);
        out.setTextIsSelectable(true);
        ScrollView sv = new ScrollView(this);
        sv.addView(out, new ViewGroup.LayoutParams(-1, -2));
        setContentView(sv);
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) run();
        else requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) run();
        else out.setText("Camera permission is required to test the camera.");
    }

    private void run() {
        StringBuilder s = new StringBuilder();
        s.append("DEVICE: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
         .append("\nAndroid ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        try {
            CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) describe(cm.getCameraCharacteristics(id), id, s);
        } catch (Exception e) { s.append("\nError: ").append(e); }
        out.setText(s.toString());
    }

    private void describe(CameraCharacteristics c, String id, StringBuilder s) {
        Integer facing = c.get(CameraCharacteristics.LENS_FACING);
        String f = facing == null ? "?" : facing == CameraCharacteristics.LENS_FACING_BACK ? "BACK"
                : facing == CameraCharacteristics.LENS_FACING_FRONT ? "FRONT" : "EXTERNAL";
        s.append("\n=== Camera ").append(id).append(" (").append(f).append(") ===\n");

        Integer hw = c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
        String[] lv = {"LIMITED", "FULL", "LEGACY", "LEVEL_3", "EXTERNAL"};
        s.append("Hardware level: ").append(hw != null && hw < lv.length ? lv[hw] : "?").append('\n');

        Rect a = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
        if (a != null) s.append(String.format("Sensor: %dx%d = %.1f MP\n", a.width(), a.height(), a.width() * a.height() / 1e6));
        SizeF ps = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);
        if (ps != null) s.append(String.format("Sensor size: %.2f x %.2f mm\n", ps.getWidth(), ps.getHeight()));

        float[] fl = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
        if (fl != null) for (float v : fl) s.append("Focal length: ").append(v).append(" mm\n");
        float[] ap = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES);
        if (ap != null) for (float v : ap) s.append("Aperture: f/").append(v).append('\n');

        int[] ois = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION);
        s.append("Optical stabilization: ").append(ois != null && ois.length > 1 ? "Yes" : "No").append('\n');
        Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
        s.append("Flash: ").append(Boolean.TRUE.equals(flash) ? "Yes" : "No").append('\n');
        Float mz = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
        s.append("Max digital zoom: ").append(mz).append("x\n");
        Float mf = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE);
        s.append("Autofocus: ").append(mf != null && mf > 0 ? "Yes" : "Fixed focus").append('\n');
        Range<Integer> iso = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
        if (iso != null) s.append("ISO range: ").append(iso).append('\n');
        Range<Long> exp = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
        if (exp != null) s.append(String.format("Exposure: %.6f s to %.2f s\n", exp.getLower() / 1e9, exp.getUpper() / 1e9));

        boolean raw = false;
        int[] caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
        if (caps != null) for (int x : caps) if (x == CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW) raw = true;
        s.append("RAW capture: ").append(raw ? "Yes" : "No").append('\n');

        Range<Integer>[] fps = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
        if (fps != null) s.append("FPS ranges: ").append(java.util.Arrays.toString(fps)).append('\n');

        StreamConfigurationMap m = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (m != null) {
            Size[] jpg = m.getOutputSizes(ImageFormat.JPEG);
            if (jpg != null && jpg.length > 0) {
                Size big = jpg[0];
                for (Size z : jpg) if ((long) z.getWidth() * z.getHeight() > (long) big.getWidth() * big.getHeight()) big = z;
                s.append("Max photo: ").append(big).append('\n');
            }
        }
        try {
            int cid = Integer.parseInt(id);
            int[] q = {CamcorderProfile.QUALITY_2160P, CamcorderProfile.QUALITY_1080P, CamcorderProfile.QUALITY_720P};
            String[] n = {"4K", "1080p", "720p"};
            s.append("Video: ");
            for (int i = 0; i < q.length; i++) if (CamcorderProfile.hasProfile(cid, q[i])) s.append(n[i]).append(' ');
            s.append('\n');
        } catch (NumberFormatException ignored) { }
    }
}
